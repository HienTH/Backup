<html>
<head>
    <title>Site under construction</title>
</head>
<body>
<img style="position:fixed; top: 0px; left: 0px; width: 100%; height: 100%" src="{{ URL::asset('images/under-construction.jpg') }}">
</body>
</html>