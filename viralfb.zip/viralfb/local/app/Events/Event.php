<?php namespace viralfb\Events;

abstract class Event {

	//

}
