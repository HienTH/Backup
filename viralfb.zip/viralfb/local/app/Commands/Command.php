<?php namespace viralfb\Commands;

abstract class Command {

	//

}
