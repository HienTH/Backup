<?php
header("Content-type: text/css; charset: UTF-8");

//Color variables
$basiccolor = $_GET["headerbar"];
$latestapptext = $_GET['latestapptext'];
$lastappbtn = $_GET['lastappbtn'];
$newappborder = $_GET['newappborder'];
$newappbtn = $_GET['newappbtn'];
$footercolor = $_GET['footercolor'];
$appcontainer = $_GET['containercolor'];
$appcontainerinside = $_GET['containerinside'];
$pagebackground = $_GET['pagebackground'];

include 'sitestyle.css';
?>




